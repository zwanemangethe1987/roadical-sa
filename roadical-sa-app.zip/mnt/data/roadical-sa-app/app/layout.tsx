import './globals.css';
export const metadata = { title: 'Roadical SA Vehicle Valuation', description: 'Online vehicle valuation and sell-my-car offer app' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}

import { NextResponse } from 'next/server';
let leads:any[] = [];

function estimateValue(year:number,mileage:number){
 const currentYear = new Date().getFullYear();
 const age = Math.max(0,currentYear-year);
 let base = 300000;
 base -= age * 22000;
 base -= Math.floor(mileage/10000)*7000;
 const low = Math.max(25000, base * 0.88);
 const high = Math.max(35000, base * 1.02);
 return {low: Math.round(low), high: Math.round(high)};
}

export async function POST(req:Request){
 const body = await req.json();
 const year = Number(body.year || 0);
 const mileage = Number(body.mileage || 0);
 const estimate = estimateValue(year,mileage);
 const lead = { id: Date.now(), createdAt: new Date().toISOString(), status:'New', estimate, ...body };
 leads.unshift(lead);
 return NextResponse.json({success:true, message:`Thank you. Estimated value range: R${estimate.low.toLocaleString()} - R${estimate.high.toLocaleString()}. Final offer subject to inspection.`, lead});
}

export async function GET(){
 return NextResponse.json({leads});
}

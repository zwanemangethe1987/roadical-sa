'use client';
import {useEffect,useState} from 'react';
export default function Admin(){
 const [leads,setLeads]=useState<any[]>([]);
 useEffect(()=>{fetch('/api/valuation').then(r=>r.json()).then(d=>setLeads(d.leads || []))},[]);
 return <main className="container">
  <div className="card"><div className="brand">Roadical SA Admin</div><p>Valuation requests received from customers.</p></div>
  <div className="card">
   {leads.length===0 && <p>No leads yet. Submit a test valuation first.</p>}
   {leads.map(l=><div className="lead" key={l.id}>
    <b>{l.fullName}</b> — {l.phone}<br/>
    {l.year} {l.make} {l.model} {l.variant}<br/>
    Mileage: {l.mileage} km | Request: {l.requestType}<br/>
    Estimated: R{l.estimate.low.toLocaleString()} - R{l.estimate.high.toLocaleString()}<br/>
    Notes: {l.conditionNotes}
   </div>)}
  </div>
 </main>
}

'use client';
import {useState} from 'react';

export default function Home(){
 const [message,setMessage]=useState('');
 async function submit(e:any){
  e.preventDefault();
  const form=e.currentTarget;
  const data=Object.fromEntries(new FormData(form).entries());
  const res=await fetch('/api/valuation',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  const json=await res.json();
  setMessage(json.message);
  form.reset();
 }
 return <main className="container">
  <div className="card">
   <div className="brand">Roadical SA</div>
   <h1>Online Vehicle Valuation</h1>
   <p>Get an estimated trade-in or cash offer for your vehicle. Final offer is subject to physical inspection.</p>
  </div>
  {message && <div className="success">{message}</div>}
  <form className="card" onSubmit={submit}>
   <h2>Owner Details</h2>
   <div className="grid">
    <input name="fullName" placeholder="Full name" required />
    <input name="phone" placeholder="WhatsApp number" required />
    <input name="email" placeholder="Email address" />
    <input name="location" placeholder="City / Area" />
   </div>
   <h2>Vehicle Details</h2>
   <div className="grid">
    <input name="make" placeholder="Make e.g. Toyota" required />
    <input name="model" placeholder="Model e.g. Corolla" required />
    <input name="year" placeholder="Year e.g. 2021" required />
    <input name="variant" placeholder="Variant e.g. 1.2T Executive" />
    <input name="mileage" placeholder="Mileage e.g. 65000" required />
    <select name="transmission"><option>Automatic</option><option>Manual</option></select>
    <select name="fuelType"><option>Petrol</option><option>Diesel</option><option>Hybrid</option><option>Electric</option></select>
    <select name="serviceHistory"><option>Full service history</option><option>Partial service history</option><option>No service history</option></select>
   </div>
   <h2>Selling Option</h2>
   <div className="grid">
    <select name="requestType"><option>Trade-in valuation</option><option>Cash offer to sell my car</option><option>Both trade-in and cash offer</option></select>
    <input name="settlementAmount" placeholder="Finance settlement amount if any" />
    <input name="wantedVehicle" placeholder="Vehicle interested in buying" />
   </div>
   <textarea name="conditionNotes" placeholder="Condition, accident history, damages, extras" rows={5}></textarea>
   <p className="small">Photos upload will be added in version 2 using Cloudinary or Supabase Storage.</p>
   <button type="submit">Submit Valuation Request</button>
  </form>
 </main>
}

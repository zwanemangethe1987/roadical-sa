# Roadical SA Vehicle Valuation App

This is a starter Next.js app for vehicle trade-in valuations and cash-offer requests.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

Admin page: http://localhost:3000/admin

## Important
This starter version stores leads in memory only. For a real business, connect Supabase database and Cloudinary/Supabase Storage for photos.

## Safety wording
Estimated values are subject to final physical inspection, mileage verification, service history, accident history, and market conditions.
